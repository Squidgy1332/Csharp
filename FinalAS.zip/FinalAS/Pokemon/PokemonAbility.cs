﻿using System;
using System.Collections.Generic;

namespace PokemonDB;

public partial class PokemonAbility
{
    public int PokemonId { get; set; }

    public int AbilityId { get; set; }
}
