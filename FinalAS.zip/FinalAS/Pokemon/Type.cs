﻿using System;
using System.Collections.Generic;

namespace PokemonDB;

public partial class Type
{
    public ulong Id { get; set; }

    public string Name { get; set; } = null!;
}
